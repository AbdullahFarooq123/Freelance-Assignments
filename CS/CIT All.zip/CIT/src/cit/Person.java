/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author
 */
public class Person {
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private String cityOfBirth;

    public Person ( ) {
        this.firstName = "";
        this.lastName = "";
        this.dateOfBirth = new Date();
        this.cityOfBirth = "";
    }

    public Person ( String firstName , String lastName , Date dateOfBirth , String cityOfBirth ) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.cityOfBirth = cityOfBirth;
    }

    public String getFirstName ( ) {
        return firstName;
    }

    public void setFirstName ( String firstName ) {
        this.firstName = firstName;
    }

    public String getLastName ( ) {
        return lastName;
    }

    public void setLastName ( String lastName ) {
        this.lastName = lastName;
    }

    public Date getDateOfBirth ( ) {
        return dateOfBirth;
    }

    public void setDateOfBirth ( Date dateOfBirth ) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getCityOfBirth ( ) {
        return cityOfBirth;
    }

    public void setCityOfBirth ( String cityOfBirth ) {
        this.cityOfBirth = cityOfBirth;
    }

    public void setAll ( String firstName , String lastName , Date dateOfBirth , String cityOfBirth ) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.cityOfBirth = cityOfBirth;
    }

    public String getAll ( ) {
        return "First name : " + firstName + "\nLast name : " + lastName + "\n" +
                dateOfBirth.getAll ( ) + "\nCity of Birth : " + cityOfBirth + "\n";
    }

    public void print ( ) {
        System.out.println ( "*****PERSON*****" );
        System.out.println ( getAll ( ) );
    }
    
    public String getName(){
        return firstName + " " + lastName;
    }
}


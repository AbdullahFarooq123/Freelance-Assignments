/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author
 */
import java.text.SimpleDateFormat;

public class Date {
    private java.util.Date date;

    public Date ( ) {
        this.date = new java.util.Date();
    }

    public Date ( java.util.Date date ) {
        this.date = date;
    }

    public java.util.Date getDate ( ) {
        return date;
    }
    
    public String getStrDate(){
        return new SimpleDateFormat ( "yyyy-MM-dd" ).format ( date );
    }
    public void setDate ( java.util.Date date ) {
        this.date = date;
    }

    public String getAll ( ) {
        return "Date : " + new SimpleDateFormat ( "yyyy-MM-dd" ).format ( date );
    }

    public void setAll ( java.util.Date date ) {
        this.date = date;
    }

    public void print ( ) {
        System.out.println ( "*****Date*****" );
        System.out.println ( getAll ( ) );
    }
}


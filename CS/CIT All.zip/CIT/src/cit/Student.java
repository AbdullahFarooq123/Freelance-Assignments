/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author
 */
import java.util.ArrayList;

public class Student {
    private int studentId;
    private Person person;
    private Address address;
    private double phone;
    private ArrayList < studentCourse > courses;

    public Student ( ) {
        this.studentId = 0;
        this.person = new Person();
        this.address = new Address();
        this.phone = 0;
        this.courses = new ArrayList <> ( );
    }

    public Student ( int studentId , Person person , Address address , double phone ) {
        this.studentId = studentId;
        this.person = person;
        this.address = address;
        this.phone = phone;
        this.courses = new ArrayList <> ( );
    }

    public Student ( int studentId , Person person , Address address , double phone , ArrayList < studentCourse > courses ) {
        this.studentId = studentId;
        this.person = person;
        this.address = address;
        this.phone = phone;
        this.courses = courses;
    }


    public int getStudentId ( ) {
        return studentId;
    }

    public void setStudentId ( int studentId ) {
        this.studentId = studentId;
    }

    public Person getPerson ( ) {
        return person;
    }

    public void setPerson ( Person person ) {
        this.person = person;
    }

    public Address getAddress ( ) {
        return address;
    }

    public void setAddress ( Address address ) {
        this.address = address;
    }

    public double getPhone ( ) {
        return phone;
    }

    public void setPhone ( double phone ) {
        this.phone = phone;
    }

    public ArrayList < studentCourse > getCourses ( ) {
        return courses;
    }

    public void setCourses ( ArrayList < studentCourse > courses ) {
        this.courses = courses;
    }

    public void setAll ( int studentId , Person person , Address address , double phone ) {
        this.studentId = studentId;
        this.person = person;
        this.address = address;
        this.phone = phone;
        this.courses = new ArrayList <> ( );
    }

    public void setAll ( int studentId , Person person , Address address , double phone , ArrayList < studentCourse > courses ) {
        this.studentId = studentId;
        this.person = person;
        this.address = address;
        this.phone = phone;
        this.courses = courses;
    }

    public String getAll ( ) {
        StringBuilder str_course = new StringBuilder ( );
        for ( studentCourse stu_course : courses )
            str_course.append ( stu_course.getAll ( ) ).append ( "\n" );
        return "Student Id : " + studentId + "\n" + person.getAll ( ) +
                address.getAll ( ) + "\nPhone : " + phone +
                "\nStudent Course : \n" + str_course.toString ( ) + "\n";
    }

    public void print ( ) {
        System.out.println ( "*****STUDENT******" );
        System.out.println ( getAll ( ) );
    }
    


}


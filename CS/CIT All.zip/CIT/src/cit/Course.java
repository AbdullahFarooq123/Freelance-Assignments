/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author
 */
public class Course {
    private int courseId;
    private String courseName;
    private Track courseTrack;
    private String courseCredit;

    public Course ( ) {
    }

    public Course ( int courseId , String courseName , Track courseTrack , String courseCredit ) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseTrack = courseTrack;
        this.courseCredit = courseCredit;
    }

    public int getCourseId ( ) {
        return courseId;
    }

    public void setCourseId ( int courseId ) {
        this.courseId = courseId;
    }

    public String getCourseName ( ) {
        return courseName;
    }

    public void setCourseName ( String courseName ) {
        this.courseName = courseName;
    }

    public Track getCourseTrack ( ) {
        return courseTrack;
    }

    public void setCourseTrack ( Track courseTrack ) {
        this.courseTrack = courseTrack;
    }

    public String getCourseCredit ( ) {
        return courseCredit;
    }

    public void setCourseCredit ( String courseCredit ) {
        this.courseCredit = courseCredit;
    }

    public void setAll ( int courseId , String courseName , Track courseTrack , String courseCredit ) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseTrack = courseTrack;
        this.courseCredit = courseCredit;
    }

    public String getAll ( ) {
        return "Course id : " + courseId + "\nCourse name : " + courseName + "\n" +
                courseTrack.getAll ( ) + "\n";
    }

    public void print ( ) {
        System.out.println ( "*****COURSE*****" );
        System.out.println ( getAll ( ) );
    }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author
 */
import java.util.ArrayList;

public class Faculty {
    private Person person;
    private ArrayList < Course > courses;

    public Faculty ( ) {
    }

    public Faculty ( Person person ) {
        this.person = person;
        this.courses = new ArrayList <> ( );
    }

    public Faculty ( Person person , ArrayList < Course > courses ) {
        this.person = person;
        this.courses = courses;
    }

    public Person getPerson ( ) {
        return person;
    }

    public void setPerson ( Person person ) {
        this.person = person;
    }

    public ArrayList < Course > getCourses ( ) {
        return courses;
    }

    public void setCourses ( ArrayList < Course > courses ) {
        this.courses = courses;
    }

    public void setAll ( Person person , ArrayList < Course > courses , ArrayList < Track > track ) {
        this.person = person;
        this.courses = courses;
    }

    public String getAll ( ) {
        StringBuilder str_course = new StringBuilder ( );
        for ( Course course : courses )
            str_course.append ( course.getAll ( ) );
        return person.getAll () + "Courses : \n" + str_course + "\n";

    }

    public void setAll ( Person person ) {
        this.person = person;
        this.courses = new ArrayList <> ( );
    }

    public void print ( ) {
        System.out.println ( "*****FACULTY******" );
        System.out.println ( getAll ( ) );
    }
}

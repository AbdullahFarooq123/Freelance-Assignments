/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author
 */
public class studentCourse {
    private int courseId;
    private double courseScore;
    private double courseGPA;
    private Session courseSession;
    private String courseStatus;

    public studentCourse ( ) {
    }

    public studentCourse ( int courseId , double courseScore , double courseGPA , Session courseSession , String courseStatus ) {
        this.courseId = courseId;
        this.courseScore = courseScore;
        this.courseGPA = courseGPA;
        this.courseSession = courseSession;
        this.courseStatus = courseStatus;
    }

    public int getCourseId ( ) {
        return courseId;
    }

    public void setCourseId ( int courseId ) {
        this.courseId = courseId;
    }

    public double getCourseScore ( ) {
        return courseScore;
    }

    public void setCourseScore ( double courseScore ) {
        this.courseScore = courseScore;
    }

    public double getCourseGPA ( ) {
        return courseGPA;
    }

    public void setCourseGPA ( double courseGPA ) {
        this.courseGPA = courseGPA;
    }

    public Session getCourseSession ( ) {
        return courseSession;
    }

    public void setCourseSession ( Session courseSession ) {
        this.courseSession = courseSession;
    }

    public String getCourseStatus ( ) {
        return courseStatus;
    }

    public void setCourseStatus ( String courseStatus ) {
        this.courseStatus = courseStatus;
    }

    public void setAll ( int courseId , double courseScore , double courseGPA , Session courseSession , String courseStatus ) {
        this.courseId = courseId;
        this.courseScore = courseScore;
        this.courseGPA = courseGPA;
        this.courseSession = courseSession;
        this.courseStatus = courseStatus;
    }

    public String getAll ( ) {
        return "Course Id : " + courseId + "\nCourse Score : " + courseScore +
                "\nCourse GPA : " + courseGPA + "\n" + courseSession.getAll ( ) +
                "Course Status : " + courseStatus + "\n";
    }

    public void print ( ) {
        System.out.println ( "*****STUDENT COURSE*****" );
        System.out.println ( getAll ( ) );
    }
}


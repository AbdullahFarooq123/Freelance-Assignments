/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author
 */
public class Session {
    private String sessionName;
    private String sessionYear;

    public Session ( ) {
    }

    public Session ( String sessionName , String sessionYear ) {
        this.sessionName = sessionName;
        this.sessionYear = sessionYear;
    }

    public String getSessionName ( ) {
        return sessionName;
    }

    public void setSessionName ( String sessionName ) {
        this.sessionName = sessionName;
    }

    public String getSessionYear ( ) {
        return sessionYear;
    }

    public void setSessionYear ( String sessionYear ) {
        this.sessionYear = sessionYear;
    }

    public void setAll ( String sessionName , String sessionYear ) {
        this.sessionName = sessionName;
        this.sessionYear = sessionYear;
    }

    public String getAll ( ) {
        return "Session name : " + sessionName + "\nSession Year : " + sessionYear + "\n";
    }

    public void print ( ) {
        System.out.println ( "*****SESSION*****" );
        System.out.println ( getAll ( ) );
    }
}


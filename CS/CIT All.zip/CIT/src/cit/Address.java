/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author
 */
public class Address {
    private int houseNo;
    private int streetNo;
    private String city;

    public Address ( ) {
        this.houseNo = 0;
        this.streetNo = 0;
        this.city = "";
    }

    public Address ( int houseNo , int streetNo , String city ) {
        this.houseNo = houseNo;
        this.streetNo = streetNo;
        this.city = city;
    }

    public int getHouseNo ( ) {
        return houseNo;
    }

    public void setHouseNo ( int houseNo ) {
        this.houseNo = houseNo;
    }

    public int getStreetNo ( ) {
        return streetNo;
    }

    public void setStreetNo ( int streetNo ) {
        this.streetNo = streetNo;
    }

    public String getCity ( ) {
        return city;
    }

    public void setCity ( String city ) {
        this.city = city;
    }

    public String getAll ( ) {
        return "House no : " + houseNo + ", Street no : " + streetNo + ", City : " + city + "\n";
    }

    public void setAll ( int houseNo , int streetNo , String city ) {
        this.houseNo = houseNo;
        this.streetNo = streetNo;
        this.city = city;
    }

    public void print ( ) {
        System.out.println ( "*****ADDRESS*****" );
        System.out.print ( getAll ( ) );
    }
}


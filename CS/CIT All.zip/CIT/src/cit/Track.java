/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cit;

/**
 *
 * @author 
 */
public class Track {
    private int trackId;
    private String name;

    public Track ( ) {
    }

    public Track ( int trackId , String name ) {
        this.trackId = trackId;
        this.name = name;
    }

    public int getTrackId ( ) {
        return trackId;
    }

    public void setTrackId ( int trackId ) {
        this.trackId = trackId;
    }

    public String getName ( ) {
        return name;
    }

    public void setName ( String name ) {
        this.name = name;
    }

    public void setAll ( int trackId , String name ) {
        this.trackId = trackId;
        this.name = name;
    }

    public String getAll ( ) {
        return "Track Id : " + trackId + "\nTrack Name : " + name + "\n";
    }

    public void print ( ) {
        System.out.println ( "*****TRACK*****" );
        System.out.println ( getAll ( ) );
    }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2l8_alreem;

import java.util.ArrayList;

/**
 *
 * @author
 */
public class Building {
    private String address;
    private ArrayList<Apartment> apartments;
    private int index = 0;

    public Building ( String address ) {
        this.address = address;
    }

    public void addApartment ( Apartment apartment ) {
        apartments.add(apartment);
    }

    public String getAddress ( ) {
        return address;
    }

    public void setAddress ( String address ) {
        this.address = address;
    }

    public int getNoOfApartments ( ) {
        return apartments.size();
    }

    public int occupiedApartments ( ) {
        return index;
    }

    public int averageNoOfPeople ( ) {
        int sum = 0;
        for ( Apartment apartment : apartments ) {
            sum += apartment.getNoOfTenants ( );
        }
        return sum / index;
    }

    public String toString(){
        StringBuilder building = new StringBuilder (  );
        for ( Apartment apartment : apartments ){
            building.append ( apartment );
        }
        return "BUILDING\n" + "Address : " + address + "\n" + building;
    }

}


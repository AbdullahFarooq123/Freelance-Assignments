/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2l8_alreem;

import java.util.ArrayList;

/**
 * @author
 */
public class Apartment {
    private int apNumber;
    private boolean occupied;
    private ArrayList<Person> persons;
    private int index = 0;

    public Apartment(){}
    public Apartment ( int apNumber, boolean occupied ) {
        this.apNumber = apNumber;
        this.occupied = occupied;
        this.persons = new ArrayList<>();
    }

    public int getApNumber ( ) {
        return apNumber;
    }

    public void setApNumber ( int apNumber ) {
        this.apNumber = apNumber;
    }

    public boolean isOccupied ( ) {
        return occupied;
    }

    public void setOccupied ( boolean occupied ) {
        this.occupied = occupied;
    }

    public ArrayList<Person> getPersons ( ) {
        return persons;
    }

    public void setPersons ( ArrayList<Person> persons ) {
        this.persons=persons;
    }
    
    public int getNoOfTenants(){
        return persons.size();
    }

    public String toString ( ) {
        StringBuilder persons = new StringBuilder ( );
        for(Person person : this.persons){
            persons.append ( person ).append("\n");
        }
        return "APARTMENT\n" + "Apartment Number : " + apNumber + "\nNo of Tenants : " + this.persons.size() + "\nOccupied : " + ( occupied ? "YES" : "NO" ) + " " + persons.toString();
    }

    public void addTenants ( Person person ) {
        persons.add(person);
    }
}

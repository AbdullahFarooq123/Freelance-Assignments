global Resistance
band_1 = input('Enter Band 1 Colour : ','s');
band_2 = input('Enter Band 2 Colour : ','s');
band_3 = input('Enter Band 3 Colour : ','s');
band_4 = input('Enter Band 4 Colour : ','s');
disp(strcat('Resistance Value is : ',resistance(band_1,band_2,band_3)))
disp(strcat('Resistance Value Range is : ',findTolerance(band_4,Resistance)))
function res = resistance(band_1,band_2,band_3)
band_1 = getValue(band_1);
if(strcmp(band_1,'Incorrect Band'))
    res = 'Bad Band 1 description';
    return
end
band_2 = getValue(band_2);
if(strcmp(band_2,'Incorrect Band'))
    res = 'Bad Band 2 description';
    return
end
band_3 = getValue(band_3);
if(strcmp(band_3,'Incorrect Band'))
    res = 'Bad Band 3 description';
    return
end
global Resistance 
Resistance = strcat(band_1,band_2,multiplier(band_3));
res = strcat(Resistance,' Ohms');
return 
end
function mult = multiplier(band_3)
mult = '';
if(strcmp(band_3,'Incorrect Band'))
    mult = ' Bad Band Description! ';
    return 
end
for i=1:str2double(band_3)
    mult = strcat(mult,'0');
end
return
end
function integerValue = getValue(band)
integerValue = 'Incorrect Band';
switch(band)
    case 'black'
        integerValue = '0';
        return
    case 'brown'
        integerValue = '1';
        return
    case 'red'
        integerValue = '2';
        return
    case 'orange'
        integerValue = '3';
        return
    case 'yellow'
        integerValue = '4';
        return
    case 'green'
        integerValue = '5';
        return
    case 'blue'
        integerValue = '6';
        return
    case 'violet'
        integerValue = '7';
        return
    case 'grey'
        integerValue = '8';
        return
    case 'white'
        integerValue = '9';
        return
end
end
function tol = tolerance(band)
tol = 'Incorrect Band';
switch(band)
    case 'gold'
        tol = '5';
        return
    case 'silver'
        tol = '10';
        return
    case 'none'
        tol = '20';
        return 
end
end
function fTol = findTolerance(band,resis)
tol = 0;
resis = str2double(resis);
switch(tolerance(band))
    case '5'
        tol = resis * 5 / 100;
    case '10'
        tol = resis * 10 / 100;
    case '20'
        tol = resis * 20 / 100;
    case 'Incorrect Band'
        fTol = ' Bad Tolerance Band Description!';
        return
end
fTol = strcat(num2str(resis-tol),' to ' ,num2str(resis+tol), ' Ohms');
return 
end
